--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webdb;
--
-- Name: webdb; Type: DATABASE; Schema: -; Owner: webadmin
--

CREATE DATABASE webdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United Kingdom.1252' LC_CTYPE = 'English_United Kingdom.1252';


ALTER DATABASE webdb OWNER TO webadmin;

\connect webdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: actidentitate; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.actidentitate (id, cnp, tip, serie, numar, datanasterii, eliberatde, dataeliberarii, loculnasterii, daaeliberarii) FROM stdin;
\.
COPY public.actidentitate (id, cnp, tip, serie, numar, datanasterii, eliberatde, dataeliberarii, loculnasterii, daaeliberarii) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: adresa; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.adresa (id, adresa, localitate, judet, tara) FROM stdin;
\.
COPY public.adresa (id, adresa, localitate, judet, tara) FROM '$$PATH$$/3314.dat';

--
-- Data for Name: societate; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.societate (id, nume, idcaen, cif, capsoc, regcom, idadresa, email, telefon, selected, fax) FROM stdin;
\.
COPY public.societate (id, nume, idcaen, cif, capsoc, regcom, idadresa, email, telefon, selected, fax) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: centrucost; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.centrucost (id, idadresa, idsocietate, nume) FROM stdin;
\.
COPY public.centrucost (id, idadresa, idsocietate, nume) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: contbancar; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.contbancar (id, iban, numebanca) FROM stdin;
\.
COPY public.contbancar (id, iban, numebanca) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: departament; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.departament (id, idadresa, idsocietate, nume, adresa) FROM stdin;
\.
COPY public.departament (id, idadresa, idsocietate, nume, adresa) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: echipa; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.echipa (id, iddepartament, nume, dataschimbare, idcontract, idsalariat) FROM stdin;
\.
COPY public.echipa (id, iddepartament, nume, dataschimbare, idcontract, idsalariat) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: punctdelucru; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.punctdelucru (id, idadresa, idsocietate, nume) FROM stdin;
\.
COPY public.punctdelucru (id, idadresa, idsocietate, nume) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.contract (id, tip, nr, marca, data, dataincepere, idpunctlucru, idcentrucost, idechipa, iddepartament, functiedebaza, calculdeduceri, studiisuperioare, normalucru, salariutarifar, monedasalariu, conditiimunca, pensieprivata, cotizatiepensieprivata, avans, monedaavans, zilecoan, ultimazilucru, casasanatate, gradinvaliditate, functie, nivelstudii, cor, sindicat, cotizatiesindicat, spor, pensionar, echipa, iddepartapent, modplata, idcontbancar) FROM stdin;
\.
COPY public.contract (id, tip, nr, marca, data, dataincepere, idpunctlucru, idcentrucost, idechipa, iddepartament, functiedebaza, calculdeduceri, studiisuperioare, normalucru, salariutarifar, monedasalariu, conditiimunca, pensieprivata, cotizatiepensieprivata, avans, monedaavans, zilecoan, ultimazilucru, casasanatate, gradinvaliditate, functie, nivelstudii, cor, sindicat, cotizatiesindicat, spor, pensionar, echipa, iddepartapent, modplata, idcontbancar) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: altebeneficii; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.altebeneficii (id, nume, valoare, procent, aplicare, idcontract) FROM stdin;
\.
COPY public.altebeneficii (id, nume, valoare, procent, aplicare, idcontract) FROM '$$PATH$$/3316.dat';

--
-- Data for Name: realizariretineri; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.realizariretineri (id, idcontract, luna, an, cam, cas, cass, deducere, duratazilucru, impozit, norma, nrpersoaneintretinere, nrtichete, orelucrate, restplata, salariupeora, salariupezi, totaldrepturi, valoaretichete, zilec, zilecm, zileco, zilecfp, zilelucrate, primabruta, totaloresuplimentare, zilecmlucratoare, zilecolucratoare, zilecfplucratoare, nroresuplimentare, salariurealizat, valcm, zileplatite, venitnet, bazaimpozit, impozitscutit, zilecontract, valco) FROM stdin;
\.
COPY public.realizariretineri (id, idcontract, luna, an, cam, cas, cass, deducere, duratazilucru, impozit, norma, nrpersoaneintretinere, nrtichete, orelucrate, restplata, salariupeora, salariupezi, totaldrepturi, valoaretichete, zilec, zilecm, zileco, zilecfp, zilelucrate, primabruta, totaloresuplimentare, zilecmlucratoare, zilecolucratoare, zilecfplucratoare, nroresuplimentare, salariurealizat, valcm, zileplatite, venitnet, bazaimpozit, impozitscutit, zilecontract, valco) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: altedrepturi; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.altedrepturi (id, valoare, idstat) FROM stdin;
\.
COPY public.altedrepturi (id, valoare, idstat) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: persoana; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.persoana (id, gen, nume, prenume, idactidentitate, idadresa, starecivila, email, telefon, cnp) FROM stdin;
\.
COPY public.persoana (id, gen, nume, prenume, idactidentitate, idadresa, starecivila, email, telefon, cnp) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: angajat; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.angajat (idpersoana, idcontract, idsocietate, idsuperior) FROM stdin;
\.
COPY public.angajat (idpersoana, idcontract, idsocietate, idsuperior) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: bazacalcul; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.bazacalcul (id, an, idangajat, luna, salariurealizat, zilelucrate) FROM stdin;
\.
COPY public.bazacalcul (id, an, idangajat, luna, salariurealizat, zilelucrate) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: burseprivate; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.burseprivate (id, idcontract, data, cota, suma) FROM stdin;
\.
COPY public.burseprivate (id, idcontract, data, cota, suma) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: caen; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.caen (id, nume) FROM stdin;
\.
COPY public.caen (id, nume) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: cerericoncediu; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.cerericoncediu (id, dela, motiv, panala, pentru, idsocietate, status, tip, societate) FROM stdin;
\.
COPY public.cerericoncediu (id, dela, motiv, panala, pentru, idsocietate, status, tip, societate) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: cm; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.cm (dela, panala, continuare, datainceput, serienrcertificat, dataeliberare, codurgenta, procent, codboalainfcont, bazacalcul, bazacalculplafonata, zilebazacalcul, mediezilnica, zilefirma, indemnizatiefirma, zilefnuass, indemnizatiefnuass, locprescriere, nravizmedic, codboala, urgenta, conditii, idcontract, id, cnpcopil, codindemnizatie, nr, serie) FROM stdin;
\.
COPY public.cm (dela, panala, continuare, datainceput, serienrcertificat, dataeliberare, codurgenta, procent, codboalainfcont, bazacalcul, bazacalculplafonata, zilebazacalcul, mediezilnica, zilefirma, indemnizatiefirma, zilefnuass, indemnizatiefnuass, locprescriere, nravizmedic, codboala, urgenta, conditii, idcontract, id, cnpcopil, codindemnizatie, nr, serie) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: co; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.co (id, tip, dela, panala, sporuripermanente, idcontract) FROM stdin;
\.
COPY public.co (id, tip, dela, panala, sporuripermanente, idcontract) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: condica; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.condica (id, inceput, sfarsit, pauzamasa, idcontract) FROM stdin;
\.
COPY public.condica (id, inceput, sfarsit, pauzamasa, idcontract) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: deduceri; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM stdin;
\.
COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: listasalariatcontract; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.listasalariatcontract (idsalariat, idcontract, dataschimbare) FROM stdin;
\.
COPY public.listasalariatcontract (idsalariat, idcontract, dataschimbare) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: oresuplimentare; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.oresuplimentare (id, nr, procent, includenormale, total, idstatsalariat, statsalariat) FROM stdin;
\.
COPY public.oresuplimentare (id, nr, procent, includenormale, total, idstatsalariat, statsalariat) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: parametriisalariu; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.parametriisalariu (id, salariumin, salariuminstudiivechime, salariumediubrut, impozit, cas, cass, cam, valtichet, date) FROM stdin;
\.
COPY public.parametriisalariu (id, salariumin, salariuminstudiivechime, salariumediubrut, impozit, cas, cass, cam, valtichet, date) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.permission (id, name) FROM stdin;
\.
COPY public.permission (id, name) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: persoanaintretinere; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.persoanaintretinere (id, nume, prenume, cnp, datanasterii, grad, gradinvaliditate, intretinut, coasigurat, idangajat) FROM stdin;
\.
COPY public.persoanaintretinere (id, nume, prenume, cnp, datanasterii, grad, gradinvaliditate, intretinut, coasigurat, idangajat) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: prime; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.prime (id, valoare, idstat, idcontract, luna, an) FROM stdin;
\.
COPY public.prime (id, valoare, idstat, idcontract, luna, an) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: retineri; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.retineri (avansnet, idstat, imprumuturi, pensiealimentara, pensiefacultativa, popriri, id) FROM stdin;
\.
COPY public.retineri (avansnet, idstat, imprumuturi, pensiealimentara, pensiefacultativa, popriri, id) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.role (id, name, "desc", descriere) FROM stdin;
\.
COPY public.role (id, name, "desc", descriere) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.roles (id, name) FROM stdin;
\.
COPY public.roles (id, name) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: roletopermission; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.roletopermission (roleid, permissionid) FROM stdin;
\.
COPY public.roletopermission (roleid, permissionid) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: salariat; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.salariat (id, idpersoana) FROM stdin;
\.
COPY public.salariat (id, idpersoana) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: sarbatori; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.sarbatori (id, dela, panala, nume) FROM stdin;
\.
COPY public.sarbatori (id, dela, panala, nume) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: sponsorizari; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.sponsorizari (id, idcontract, denumire, cui, cota, suma) FROM stdin;
\.
COPY public.sponsorizari (id, idcontract, denumire, cui, cota, suma) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: spor; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.spor (id, nume, valoare, procent, aplicare, idstat) FROM stdin;
\.
COPY public.spor (id, nume, valoare, procent, aplicare, idstat) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: sporpermanent; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.sporpermanent (id, nume, valoare, procent, aplicare, idcontract, idstat) FROM stdin;
\.
COPY public.sporpermanent (id, nume, valoare, procent, aplicare, idcontract, idstat) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: tichete; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.tichete (id, tip, nr, restituite, valoare, impozabil, idstatsalariat, idstat) FROM stdin;
\.
COPY public.tichete (id, tip, nr, restituite, valoare, impozabil, idstatsalariat, idstat) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.users (id, email, password, username, id_angajat, gen) FROM stdin;
\.
COPY public.users (id, email, password, username, id_angajat, gen) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: user_financials; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.user_financials (id, stat_date, sum_of_payments, user_id) FROM stdin;
\.
COPY public.user_financials (id, stat_date, sum_of_payments, user_id) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.
COPY public.user_roles (user_id, role_id) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: user_societati; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.user_societati (user_id, societate_id) FROM stdin;
\.
COPY public.user_societati (user_id, societate_id) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: user_statistics; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.user_statistics (id, number_of_logins_per_day, stat_date, user_id) FROM stdin;
\.
COPY public.user_statistics (id, number_of_logins_per_day, stat_date, user_id) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: usertorole; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.usertorole (roleid, userid) FROM stdin;
\.
COPY public.usertorole (roleid, userid) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: zilecodisponibile; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.zilecodisponibile (id, nr, idcontract) FROM stdin;
\.
COPY public.zilecodisponibile (id, nr, idcontract) FROM '$$PATH$$/3392.dat';

--
-- Name: actidentitate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.actidentitate_id_seq', 75, true);


--
-- Name: adresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.adresa_id_seq', 101, true);


--
-- Name: altebeneficii_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.altebeneficii_id_seq', 1, false);


--
-- Name: altedrepturi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.altedrepturi_id_seq', 1, false);


--
-- Name: bazacalcul_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.bazacalcul_id_seq', 285, true);


--
-- Name: burseprivate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.burseprivate_id_seq', 1, false);


--
-- Name: caen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.caen_id_seq', 1, false);


--
-- Name: centrucost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.centrucost_id_seq', 5, true);


--
-- Name: cerericoncediu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.cerericoncediu_id_seq', 1, false);


--
-- Name: cm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.cm_id_seq', 26, true);


--
-- Name: co_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.co_id_seq', 92, true);


--
-- Name: contbancar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.contbancar_id_seq', 1, true);


--
-- Name: contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.contract_id_seq', 153, true);


--
-- Name: deduceri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.deduceri_id_seq', 35, true);


--
-- Name: departament_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.departament_id_seq', 1, false);


--
-- Name: echipa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.echipa_id_seq', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.hibernate_sequence', 3, true);


--
-- Name: oresuplimentare_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.oresuplimentare_id_seq', 38, true);


--
-- Name: parametriisalariu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.parametriisalariu_id_seq', 3, true);


--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.permission_id_seq', 1, true);


--
-- Name: persoana_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.persoana_id_seq', 111, true);


--
-- Name: persoanaintretinere_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.persoanaintretinere_id_seq', 9, true);


--
-- Name: prime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.prime_id_seq', 1, false);


--
-- Name: punctlucru_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.punctlucru_id_seq', 1, false);


--
-- Name: retineri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.retineri_id_seq', 285, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.role_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: salariat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.salariat_id_seq', 1, false);


--
-- Name: sarbatori_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.sarbatori_id_seq', 96, true);


--
-- Name: societate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.societate_id_seq', 35, true);


--
-- Name: sponsorizari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.sponsorizari_id_seq', 1, false);


--
-- Name: spor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.spor_id_seq', 1, false);


--
-- Name: sporpermanent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.sporpermanent_id_seq', 1, false);


--
-- Name: statsalariat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.statsalariat_id_seq', 299, true);


--
-- Name: tichete_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.tichete_id_seq', 1, false);


--
-- Name: user_financials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.user_financials_id_seq', 1, false);


--
-- Name: user_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.user_statistics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.users_id_seq', 28, true);


--
-- Name: zilecodisponibile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.zilecodisponibile_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

