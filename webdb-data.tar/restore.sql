--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webdb;
--
-- Name: webdb; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE webdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


\connect webdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: actidentitate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actidentitate (id, cnp, tip, serie, numar, datanasterii, eliberatde, dataeliberarii, loculnasterii, daaeliberarii) FROM stdin;
\.
COPY public.actidentitate (id, cnp, tip, serie, numar, datanasterii, eliberatde, dataeliberarii, loculnasterii, daaeliberarii) FROM '$$PATH$$/3281.dat';

--
-- Data for Name: adresa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.adresa (id, adresa, localitate, judet, tara) FROM stdin;
\.
COPY public.adresa (id, adresa, localitate, judet, tara) FROM '$$PATH$$/3283.dat';

--
-- Data for Name: altebeneficii; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.altebeneficii (id, nume, valoare, procent, aplicare, idcontract) FROM stdin;
\.
COPY public.altebeneficii (id, nume, valoare, procent, aplicare, idcontract) FROM '$$PATH$$/3285.dat';

--
-- Data for Name: altedrepturi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.altedrepturi (id, valoare, idstat) FROM stdin;
\.
COPY public.altedrepturi (id, valoare, idstat) FROM '$$PATH$$/3287.dat';

--
-- Data for Name: angajat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.angajat (idpersoana, idcontract, idsocietate) FROM stdin;
\.
COPY public.angajat (idpersoana, idcontract, idsocietate) FROM '$$PATH$$/3289.dat';

--
-- Data for Name: bazacalcul; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bazacalcul (id, an, idangajat, luna, salariurealizat, zilelucrate) FROM stdin;
\.
COPY public.bazacalcul (id, an, idangajat, luna, salariurealizat, zilelucrate) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: burseprivate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.burseprivate (id, idcontract, data, cota, suma) FROM stdin;
\.
COPY public.burseprivate (id, idcontract, data, cota, suma) FROM '$$PATH$$/3290.dat';

--
-- Data for Name: caen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.caen (id, nume) FROM stdin;
\.
COPY public.caen (id, nume) FROM '$$PATH$$/3292.dat';

--
-- Data for Name: centrucost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.centrucost (id, idadresa, idsocietate, nume) FROM stdin;
\.
COPY public.centrucost (id, idadresa, idsocietate, nume) FROM '$$PATH$$/3294.dat';

--
-- Data for Name: cm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cm (dela, panala, continuare, datainceput, serienrcertificat, dataeliberare, codurgenta, procent, codboalainfcont, bazacalcul, bazacalculplafonata, zilebazacalcul, mediezilnica, zilefirma, indemnizatiefirma, zilefnuass, indemnizatiefnuass, locprescriere, nravizmedic, codboala, urgenta, conditii, idcontract, id) FROM stdin;
\.
COPY public.cm (dela, panala, continuare, datainceput, serienrcertificat, dataeliberare, codurgenta, procent, codboalainfcont, bazacalcul, bazacalculplafonata, zilebazacalcul, mediezilnica, zilefirma, indemnizatiefirma, zilefnuass, indemnizatiefnuass, locprescriere, nravizmedic, codboala, urgenta, conditii, idcontract, id) FROM '$$PATH$$/3296.dat';

--
-- Data for Name: co; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.co (id, tip, dela, panala, sporuripermanente, idcontract) FROM stdin;
\.
COPY public.co (id, tip, dela, panala, sporuripermanente, idcontract) FROM '$$PATH$$/3298.dat';

--
-- Data for Name: condica; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.condica (id, inceput, sfarsit, pauzamasa, idcontract) FROM stdin;
\.
COPY public.condica (id, inceput, sfarsit, pauzamasa, idcontract) FROM '$$PATH$$/3300.dat';

--
-- Data for Name: contbancar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contbancar (iban, numebanca) FROM stdin;
\.
COPY public.contbancar (iban, numebanca) FROM '$$PATH$$/3301.dat';

--
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract (id, tip, nr, marca, data, dataincepere, idpunctlucru, idcentrucost, idechipa, iddepartament, functiedebaza, calculdeduceri, studiisuperioare, normalucru, salariutarifar, monedasalariu, modplata, conditiimunca, pensieprivata, cotizatiepensieprivata, avans, monedaavans, zilecoan, ultimazilucru, casasanatate, gradinvaliditate, functie, nivelstudii, cor, sindicat, cotizatiesindicat, spor, pensionar, echipa) FROM stdin;
\.
COPY public.contract (id, tip, nr, marca, data, dataincepere, idpunctlucru, idcentrucost, idechipa, iddepartament, functiedebaza, calculdeduceri, studiisuperioare, normalucru, salariutarifar, monedasalariu, modplata, conditiimunca, pensieprivata, cotizatiepensieprivata, avans, monedaavans, zilecoan, ultimazilucru, casasanatate, gradinvaliditate, functie, nivelstudii, cor, sindicat, cotizatiesindicat, spor, pensionar, echipa) FROM '$$PATH$$/3302.dat';

--
-- Data for Name: deduceri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM stdin;
\.
COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM '$$PATH$$/3304.dat';

--
-- Data for Name: departament; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departament (id, idadresa, idsocietate, nume, adresa) FROM stdin;
\.
COPY public.departament (id, idadresa, idsocietate, nume, adresa) FROM '$$PATH$$/3306.dat';

--
-- Data for Name: echipa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.echipa (id, iddepartament, nume, dataschimbare, idcontract, idsalariat) FROM stdin;
\.
COPY public.echipa (id, iddepartament, nume, dataschimbare, idcontract, idsalariat) FROM '$$PATH$$/3308.dat';

--
-- Data for Name: listacontbancar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listacontbancar (idsocietate, iban) FROM stdin;
\.
COPY public.listacontbancar (idsocietate, iban) FROM '$$PATH$$/3311.dat';

--
-- Data for Name: listasalariatcontract; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listasalariatcontract (idsalariat, idcontract, dataschimbare) FROM stdin;
\.
COPY public.listasalariatcontract (idsalariat, idcontract, dataschimbare) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: oresuplimentare; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oresuplimentare (id, nr, procent, includenormale, total, idstatsalariat) FROM stdin;
\.
COPY public.oresuplimentare (id, nr, procent, includenormale, total, idstatsalariat) FROM '$$PATH$$/3313.dat';

--
-- Data for Name: parametriisalariu; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parametriisalariu (id, salariumin, salariuminstudiivechime, salariumediubrut, impozit, cas, cass, cam, valtichet, date) FROM stdin;
\.
COPY public.parametriisalariu (id, salariumin, salariuminstudiivechime, salariumediubrut, impozit, cas, cass, cam, valtichet, date) FROM '$$PATH$$/3315.dat';

--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission (id, name) FROM stdin;
\.
COPY public.permission (id, name) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: persoana; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.persoana (id, gen, nume, prenume, idactidentitate, idadresa, starecivila, email, telefon, cnp) FROM stdin;
\.
COPY public.persoana (id, gen, nume, prenume, idactidentitate, idadresa, starecivila, email, telefon, cnp) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: persoanaintretinere; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.persoanaintretinere (id, nume, prenume, cnp, datanasterii, grad, gradinvaliditate, intretinut, coasigurat, idangajat) FROM stdin;
\.
COPY public.persoanaintretinere (id, nume, prenume, cnp, datanasterii, grad, gradinvaliditate, intretinut, coasigurat, idangajat) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: prime; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prime (id, valoare, idstat, idcontract, luna, an) FROM stdin;
\.
COPY public.prime (id, valoare, idstat, idcontract, luna, an) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: punctdelucru; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.punctdelucru (id, idadresa, idsocietate, nume) FROM stdin;
\.
COPY public.punctdelucru (id, idadresa, idsocietate, nume) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: realizariretineri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.realizariretineri (id, idcontract, luna, an, cam, cas, cass, deducere, duratazilucru, impozit, norma, nrpersoaneintretinere, nrtichete, orelucrate, restplata, salariupeora, salariupezi, totaldrepturi, valoaretichete, zilec, zilecm, zileco, zileconeplatit, zilelucrate, primabruta, totaloresuplimentare, zilecmlucratoare, zilecolucratoare, zileconeplatitlucratoare, nroresuplimentare, salariurealizat, valcm, zileplatite, venitnet, bazaimpozit, impozitscutit) FROM stdin;
\.
COPY public.realizariretineri (id, idcontract, luna, an, cam, cas, cass, deducere, duratazilucru, impozit, norma, nrpersoaneintretinere, nrtichete, orelucrate, restplata, salariupeora, salariupezi, totaldrepturi, valoaretichete, zilec, zilecm, zileco, zileconeplatit, zilelucrate, primabruta, totaloresuplimentare, zilecmlucratoare, zilecolucratoare, zileconeplatitlucratoare, nroresuplimentare, salariurealizat, valcm, zileplatite, venitnet, bazaimpozit, impozitscutit) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: retineri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retineri (avansnet, idstat, imprumuturi, pensiealimentara, pensiefacultativa, popriri, id) FROM stdin;
\.
COPY public.retineri (avansnet, idstat, imprumuturi, pensiealimentara, pensiefacultativa, popriri, id) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role (id, name, "desc", descriere) FROM stdin;
\.
COPY public.role (id, name, "desc", descriere) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name) FROM stdin;
\.
COPY public.roles (id, name) FROM '$$PATH$$/3272.dat';

--
-- Data for Name: roletopermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roletopermission (roleid, permissionid) FROM stdin;
\.
COPY public.roletopermission (roleid, permissionid) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: salariat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salariat (id, idpersoana) FROM stdin;
\.
COPY public.salariat (id, idpersoana) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: sarbatori; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sarbatori (id, dela, panala, nume) FROM stdin;
\.
COPY public.sarbatori (id, dela, panala, nume) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: societate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.societate (id, nume, idcaen, cif, capsoc, regcom, idadresa, email, telefon, selected) FROM stdin;
\.
COPY public.societate (id, nume, idcaen, cif, capsoc, regcom, idadresa, email, telefon, selected) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: sponsorizari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sponsorizari (id, idcontract, denumire, cui, cota, suma) FROM stdin;
\.
COPY public.sponsorizari (id, idcontract, denumire, cui, cota, suma) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: spor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spor (id, nume, valoare, procent, aplicare, idstat) FROM stdin;
\.
COPY public.spor (id, nume, valoare, procent, aplicare, idstat) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: sporpermanent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sporpermanent (id, nume, valoare, procent, aplicare, idcontract, idstat) FROM stdin;
\.
COPY public.sporpermanent (id, nume, valoare, procent, aplicare, idcontract, idstat) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: tichete; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tichete (id, tip, nr, restituite, valoare, impozabil, idstatsalariat, idstat) FROM stdin;
\.
COPY public.tichete (id, tip, nr, restituite, valoare, impozabil, idstatsalariat, idstat) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, username, password, nume, prenume) FROM stdin;
\.
COPY public."user" (id, username, password, nume, prenume) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: user_financials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_financials (id, stat_date, sum_of_payments, user_id) FROM stdin;
\.
COPY public.user_financials (id, stat_date, sum_of_payments, user_id) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.
COPY public.user_roles (user_id, role_id) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: user_statistics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_statistics (id, number_of_logins_per_day, stat_date, user_id) FROM stdin;
\.
COPY public.user_statistics (id, number_of_logins_per_day, stat_date, user_id) FROM '$$PATH$$/3277.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password, username) FROM stdin;
\.
COPY public.users (id, email, password, username) FROM '$$PATH$$/3279.dat';

--
-- Data for Name: usertorole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usertorole (userid, roleid) FROM stdin;
\.
COPY public.usertorole (userid, roleid) FROM '$$PATH$$/3349.dat';

--
-- Data for Name: zilecodisponibile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.zilecodisponibile (id, nr, idcontract) FROM stdin;
\.
COPY public.zilecodisponibile (id, nr, idcontract) FROM '$$PATH$$/3350.dat';

--
-- Name: actidentitate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actidentitate_id_seq', 59, true);


--
-- Name: adresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.adresa_id_seq', 74, true);


--
-- Name: altebeneficii_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.altebeneficii_id_seq', 1, false);


--
-- Name: altedrepturi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.altedrepturi_id_seq', 1, false);


--
-- Name: bazacalcul_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bazacalcul_id_seq', 107, true);


--
-- Name: burseprivate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.burseprivate_id_seq', 1, false);


--
-- Name: caen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.caen_id_seq', 1, false);


--
-- Name: centrucost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.centrucost_id_seq', 5, true);


--
-- Name: cm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cm_id_seq', 15, true);


--
-- Name: co_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.co_id_seq', 69, true);


--
-- Name: contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_id_seq', 143, true);


--
-- Name: deduceri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deduceri_id_seq', 35, true);


--
-- Name: departament_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departament_id_seq', 1, false);


--
-- Name: echipa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.echipa_id_seq', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hibernate_sequence', 3, true);


--
-- Name: oresuplimentare_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oresuplimentare_id_seq', 34, true);


--
-- Name: parametriisalariu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parametriisalariu_id_seq', 1, false);


--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permission_id_seq', 1, true);


--
-- Name: persoana_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.persoana_id_seq', 95, true);


--
-- Name: persoanaintretinere_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.persoanaintretinere_id_seq', 8, true);


--
-- Name: prime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prime_id_seq', 1, false);


--
-- Name: punctlucru_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.punctlucru_id_seq', 1, false);


--
-- Name: retineri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.retineri_id_seq', 107, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: salariat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salariat_id_seq', 1, false);


--
-- Name: sarbatori_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sarbatori_id_seq', 1, false);


--
-- Name: societate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.societate_id_seq', 23, true);


--
-- Name: sponsorizari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sponsorizari_id_seq', 1, false);


--
-- Name: spor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spor_id_seq', 1, false);


--
-- Name: sporpermanent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sporpermanent_id_seq', 1, false);


--
-- Name: statsalariat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statsalariat_id_seq', 121, true);


--
-- Name: tichete_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tichete_id_seq', 1, false);


--
-- Name: user_financials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_financials_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_id_seq', 1, true);


--
-- Name: user_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_statistics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: zilecodisponibile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.zilecodisponibile_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

