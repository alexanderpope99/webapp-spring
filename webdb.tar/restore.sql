--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webdb;
--
-- Name: webdb; Type: DATABASE; Schema: -; Owner: webadmin
--

CREATE DATABASE webdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Romanian_Romania.1252' LC_CTYPE = 'Romanian_Romania.1252';


ALTER DATABASE webdb OWNER TO webadmin;

\connect webdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deduceri; Type: TABLE; Schema: public; Owner: webadmin
--

CREATE TABLE public.deduceri (
    id integer NOT NULL,
    dela real NOT NULL,
    panala real NOT NULL,
    zero integer NOT NULL,
    una integer NOT NULL,
    doua integer NOT NULL,
    trei integer NOT NULL,
    patru integer NOT NULL
);


ALTER TABLE public.deduceri OWNER TO webadmin;

--
-- Name: deduceri_id_seq; Type: SEQUENCE; Schema: public; Owner: webadmin
--

CREATE SEQUENCE public.deduceri_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deduceri_id_seq OWNER TO webadmin;

--
-- Name: deduceri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webadmin
--

ALTER SEQUENCE public.deduceri_id_seq OWNED BY public.deduceri.id;


--
-- Name: deduceri id; Type: DEFAULT; Schema: public; Owner: webadmin
--

ALTER TABLE ONLY public.deduceri ALTER COLUMN id SET DEFAULT nextval('public.deduceri_id_seq'::regclass);


--
-- Data for Name: deduceri; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM stdin;
\.
COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM '$$PATH$$/3023.dat';

--
-- Name: deduceri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.deduceri_id_seq', 35, true);


--
-- Name: deduceri deduceri_pkey; Type: CONSTRAINT; Schema: public; Owner: webadmin
--

ALTER TABLE ONLY public.deduceri
    ADD CONSTRAINT deduceri_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

