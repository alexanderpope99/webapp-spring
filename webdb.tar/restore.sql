--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webdb;
--
-- Name: webdb; Type: DATABASE; Schema: -; Owner: webadmin
--

CREATE DATABASE webdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Romanian_Romania.1252' LC_CTYPE = 'Romanian_Romania.1252';


ALTER DATABASE webdb OWNER TO webadmin;

\connect webdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: actidentitate; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.actidentitate (id, cnp, tip, serie, numar, datanasterii, eliberatde, dataeliberarii, loculnasterii, daaeliberarii) FROM stdin;
\.
COPY public.actidentitate (id, cnp, tip, serie, numar, datanasterii, eliberatde, dataeliberarii, loculnasterii, daaeliberarii) FROM '$$PATH$$/3210.dat';

--
-- Data for Name: adresa; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.adresa (id, adresa, localitate, judet, tara) FROM stdin;
\.
COPY public.adresa (id, adresa, localitate, judet, tara) FROM '$$PATH$$/3212.dat';

--
-- Data for Name: altebeneficii; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.altebeneficii (id, nume, valoare, procent, aplicare, idcontract) FROM stdin;
\.
COPY public.altebeneficii (id, nume, valoare, procent, aplicare, idcontract) FROM '$$PATH$$/3214.dat';

--
-- Data for Name: altedrepturi; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.altedrepturi (id, valoare, idstat) FROM stdin;
\.
COPY public.altedrepturi (id, valoare, idstat) FROM '$$PATH$$/3216.dat';

--
-- Data for Name: angajat; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.angajat (idpersoana, idcontract, idsocietate) FROM stdin;
\.
COPY public.angajat (idpersoana, idcontract, idsocietate) FROM '$$PATH$$/3218.dat';

--
-- Data for Name: burseprivate; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.burseprivate (id, idcontract, data, cota, suma) FROM stdin;
\.
COPY public.burseprivate (id, idcontract, data, cota, suma) FROM '$$PATH$$/3219.dat';

--
-- Data for Name: caen; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.caen (id, nume) FROM stdin;
\.
COPY public.caen (id, nume) FROM '$$PATH$$/3221.dat';

--
-- Data for Name: centrucost; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.centrucost (id, idadresa, idsocietate, nume) FROM stdin;
\.
COPY public.centrucost (id, idadresa, idsocietate, nume) FROM '$$PATH$$/3223.dat';

--
-- Data for Name: cm; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.cm (dela, panala, continuare, datainceput, serienrcertificat, dataeliberare, codurgenta, procent, codboalainfcont, bazacalcul, bazacalculplafonata, zilebazacalcul, mediezilnica, zilefirma, indemnizatiefirma, zilefnuass, indemnizatiefnuass, locprescriere, nravizmedic, codboala, urgenta, conditii, idcontract, id) FROM stdin;
\.
COPY public.cm (dela, panala, continuare, datainceput, serienrcertificat, dataeliberare, codurgenta, procent, codboalainfcont, bazacalcul, bazacalculplafonata, zilebazacalcul, mediezilnica, zilefirma, indemnizatiefirma, zilefnuass, indemnizatiefnuass, locprescriere, nravizmedic, codboala, urgenta, conditii, idcontract, id) FROM '$$PATH$$/3225.dat';

--
-- Data for Name: co; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.co (id, tip, dela, panala, sporuripermanente, idcontract) FROM stdin;
\.
COPY public.co (id, tip, dela, panala, sporuripermanente, idcontract) FROM '$$PATH$$/3226.dat';

--
-- Data for Name: condica; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.condica (id, inceput, sfarsit, pauzamasa, idcontract) FROM stdin;
\.
COPY public.condica (id, inceput, sfarsit, pauzamasa, idcontract) FROM '$$PATH$$/3228.dat';

--
-- Data for Name: contbancar; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.contbancar (iban, numebanca) FROM stdin;
\.
COPY public.contbancar (iban, numebanca) FROM '$$PATH$$/3229.dat';

--
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.contract (id, tip, nr, marca, data, dataincepere, idpunctlucru, idcentrucost, idechipa, iddepartament, functiedebaza, calculdeduceri, studiisuperioare, normalucru, salariutarifar, monedasalariu, modplata, conditiimunca, pensieprivata, cotizatiepensieprivata, avans, monedaavans, zilecoan, ultimazilucru, casasanatate, gradinvaliditate, functie, nivelstudii, cor, sindicat, cotizatiesindicat, spor, pensionar, echipa) FROM stdin;
\.
COPY public.contract (id, tip, nr, marca, data, dataincepere, idpunctlucru, idcentrucost, idechipa, iddepartament, functiedebaza, calculdeduceri, studiisuperioare, normalucru, salariutarifar, monedasalariu, modplata, conditiimunca, pensieprivata, cotizatiepensieprivata, avans, monedaavans, zilecoan, ultimazilucru, casasanatate, gradinvaliditate, functie, nivelstudii, cor, sindicat, cotizatiesindicat, spor, pensionar, echipa) FROM '$$PATH$$/3230.dat';

--
-- Data for Name: deduceri; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM stdin;
\.
COPY public.deduceri (id, dela, panala, zero, una, doua, trei, patru) FROM '$$PATH$$/3280.dat';

--
-- Data for Name: departament; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.departament (id, idadresa, idsocietate, nume, adresa) FROM stdin;
\.
COPY public.departament (id, idadresa, idsocietate, nume, adresa) FROM '$$PATH$$/3232.dat';

--
-- Data for Name: echipa; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.echipa (id, iddepartament, nume, dataschimbare, idcontract, idsalariat) FROM stdin;
\.
COPY public.echipa (id, iddepartament, nume, dataschimbare, idcontract, idsalariat) FROM '$$PATH$$/3234.dat';

--
-- Data for Name: listacontbancar; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.listacontbancar (idsocietate, iban) FROM stdin;
\.
COPY public.listacontbancar (idsocietate, iban) FROM '$$PATH$$/3236.dat';

--
-- Data for Name: listasalariatcontract; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.listasalariatcontract (idsalariat, idcontract, dataschimbare) FROM stdin;
\.
COPY public.listasalariatcontract (idsalariat, idcontract, dataschimbare) FROM '$$PATH$$/3237.dat';

--
-- Data for Name: oresuplimentare; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.oresuplimentare (id, nr, procent, includenormale, total, idcontract) FROM stdin;
\.
COPY public.oresuplimentare (id, nr, procent, includenormale, total, idcontract) FROM '$$PATH$$/3238.dat';

--
-- Data for Name: parametriisalariu; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.parametriisalariu (id, salariumin, salariuminstudiivechime, salariumediubrut, impozit, cas, cass, cam, valtichet) FROM stdin;
\.
COPY public.parametriisalariu (id, salariumin, salariuminstudiivechime, salariumediubrut, impozit, cas, cass, cam, valtichet) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.permission (id, name) FROM stdin;
\.
COPY public.permission (id, name) FROM '$$PATH$$/3240.dat';

--
-- Data for Name: persoana; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.persoana (id, gen, nume, prenume, idactidentitate, idadresa, starecivila, email, telefon, cnp) FROM stdin;
\.
COPY public.persoana (id, gen, nume, prenume, idactidentitate, idadresa, starecivila, email, telefon, cnp) FROM '$$PATH$$/3242.dat';

--
-- Data for Name: persoanaintretinere; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.persoanaintretinere (id, nume, prenume, cnp, datanasterii, grad, gradinvaliditate, intretinut, coasigurat, idaangajat) FROM stdin;
\.
COPY public.persoanaintretinere (id, nume, prenume, cnp, datanasterii, grad, gradinvaliditate, intretinut, coasigurat, idaangajat) FROM '$$PATH$$/3244.dat';

--
-- Data for Name: prime; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.prime (id, valoare, idstat, idcontract, data) FROM stdin;
\.
COPY public.prime (id, valoare, idstat, idcontract, data) FROM '$$PATH$$/3246.dat';

--
-- Data for Name: punctdelucru; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.punctdelucru (id, idadresa, idsocietate, nume) FROM stdin;
\.
COPY public.punctdelucru (id, idadresa, idsocietate, nume) FROM '$$PATH$$/3248.dat';

--
-- Data for Name: retineri; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.retineri (id, valoare, idstat) FROM stdin;
\.
COPY public.retineri (id, valoare, idstat) FROM '$$PATH$$/3250.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.role (id, name, "desc") FROM stdin;
\.
COPY public.role (id, name, "desc") FROM '$$PATH$$/3251.dat';

--
-- Data for Name: roletopermission; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.roletopermission (roleid, permissionid) FROM stdin;
\.
COPY public.roletopermission (roleid, permissionid) FROM '$$PATH$$/3253.dat';

--
-- Data for Name: salariat; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.salariat (id, idpersoana) FROM stdin;
\.
COPY public.salariat (id, idpersoana) FROM '$$PATH$$/3254.dat';

--
-- Data for Name: sarbatori; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sarbatori (id, dela, panala, nume) FROM stdin;
\.
COPY public.sarbatori (id, dela, panala, nume) FROM '$$PATH$$/3278.dat';

--
-- Data for Name: societate; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.societate (id, nume, idcaen, cif, capsoc, regcom, idadresa, email, telefon, idcontract, includenormale, nr, procent, total) FROM stdin;
\.
COPY public.societate (id, nume, idcaen, cif, capsoc, regcom, idadresa, email, telefon, idcontract, includenormale, nr, procent, total) FROM '$$PATH$$/3256.dat';

--
-- Data for Name: sponsorizari; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.sponsorizari (id, idcontract, denumire, cui, cota, suma) FROM stdin;
\.
COPY public.sponsorizari (id, idcontract, denumire, cui, cota, suma) FROM '$$PATH$$/3258.dat';

--
-- Data for Name: spor; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.spor (id, nume, valoare, procent, aplicare, idstat) FROM stdin;
\.
COPY public.spor (id, nume, valoare, procent, aplicare, idstat) FROM '$$PATH$$/3260.dat';

--
-- Data for Name: sporpermanent; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.sporpermanent (id, nume, valoare, procent, aplicare, idcontract, idstat) FROM stdin;
\.
COPY public.sporpermanent (id, nume, valoare, procent, aplicare, idcontract, idstat) FROM '$$PATH$$/3262.dat';

--
-- Data for Name: statsalariat; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.statsalariat (id, data, idcontract) FROM stdin;
\.
COPY public.statsalariat (id, data, idcontract) FROM '$$PATH$$/3264.dat';

--
-- Data for Name: tichete; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.tichete (id, tip, nr, restituite, valoare, impozabil, idstat, idcontract) FROM stdin;
\.
COPY public.tichete (id, tip, nr, restituite, valoare, impozabil, idstat, idcontract) FROM '$$PATH$$/3266.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public."user" (id, username, password, nume, prenume, societateselectata) FROM stdin;
\.
COPY public."user" (id, username, password, nume, prenume, societateselectata) FROM '$$PATH$$/3268.dat';

--
-- Data for Name: usertorole; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.usertorole (userid, roleid) FROM stdin;
\.
COPY public.usertorole (userid, roleid) FROM '$$PATH$$/3270.dat';

--
-- Data for Name: zilecodisponibile; Type: TABLE DATA; Schema: public; Owner: webadmin
--

COPY public.zilecodisponibile (id, nr, idcontract) FROM stdin;
\.
COPY public.zilecodisponibile (id, nr, idcontract) FROM '$$PATH$$/3271.dat';

--
-- Name: actidentitate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.actidentitate_id_seq', 22, true);


--
-- Name: adresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.adresa_id_seq', 44, true);


--
-- Name: altebeneficii_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.altebeneficii_id_seq', 1, false);


--
-- Name: altedrepturi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.altedrepturi_id_seq', 1, false);


--
-- Name: burseprivate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.burseprivate_id_seq', 1, false);


--
-- Name: caen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.caen_id_seq', 1, false);


--
-- Name: centrucost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.centrucost_id_seq', 5, true);


--
-- Name: cm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.cm_id_seq', 11, true);


--
-- Name: co_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.co_id_seq', 49, true);


--
-- Name: contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.contract_id_seq', 133, true);


--
-- Name: deduceri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.deduceri_id_seq', 35, true);


--
-- Name: departament_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.departament_id_seq', 1, false);


--
-- Name: echipa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.echipa_id_seq', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.hibernate_sequence', 3, true);


--
-- Name: oresuplimentare_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.oresuplimentare_id_seq', 1, false);


--
-- Name: parametriisalariu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.parametriisalariu_id_seq', 1, false);


--
-- Name: permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.permission_id_seq', 1, true);


--
-- Name: persoana_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.persoana_id_seq', 74, true);


--
-- Name: persoanaintretinere_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.persoanaintretinere_id_seq', 1, false);


--
-- Name: prime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.prime_id_seq', 1, false);


--
-- Name: punctlucru_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.punctlucru_id_seq', 1, false);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.role_id_seq', 1, true);


--
-- Name: salariat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.salariat_id_seq', 1, false);


--
-- Name: sarbatori_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sarbatori_id_seq', 1, false);


--
-- Name: societate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.societate_id_seq', 18, true);


--
-- Name: sponsorizari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.sponsorizari_id_seq', 1, false);


--
-- Name: spor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.spor_id_seq', 1, false);


--
-- Name: sporpermanent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.sporpermanent_id_seq', 1, false);


--
-- Name: statsalariat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.statsalariat_id_seq', 1, false);


--
-- Name: tichete_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.tichete_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.user_id_seq', 1, true);


--
-- Name: zilecodisponibile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webadmin
--

SELECT pg_catalog.setval('public.zilecodisponibile_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

