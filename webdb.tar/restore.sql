--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webdb;
--
-- Name: webdb; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE webdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Romanian_Romania.1252' LC_CTYPE = 'Romanian_Romania.1252';


\connect webdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actidentitate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actidentitate (
    id integer NOT NULL,
    cnp text,
    tip text,
    serie text,
    numar text,
    datanasterii date,
    eliberatde text,
    dataeliberarii text,
    loculnasterii text,
    daaeliberarii character varying(255)
);


--
-- Name: actidentitate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actidentitate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actidentitate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actidentitate_id_seq OWNED BY public.actidentitate.id;


--
-- Name: adresa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.adresa (
    id integer NOT NULL,
    adresa text,
    localitate text,
    judet text,
    tara text
);


--
-- Name: adresa_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.adresa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: adresa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.adresa_id_seq OWNED BY public.adresa.id;


--
-- Name: altebeneficii; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.altebeneficii (
    id integer NOT NULL,
    nume text,
    valoare real,
    procent real,
    aplicare text,
    idcontract integer
);


--
-- Name: altebeneficii_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.altebeneficii_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: altebeneficii_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.altebeneficii_id_seq OWNED BY public.altebeneficii.id;


--
-- Name: altedrepturi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.altedrepturi (
    id integer NOT NULL,
    valoare real,
    idstat integer
);


--
-- Name: altedrepturi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.altedrepturi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: altedrepturi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.altedrepturi_id_seq OWNED BY public.altedrepturi.id;


--
-- Name: angajat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.angajat (
    idpersoana integer NOT NULL,
    idcontract integer,
    idsocietate integer
);


--
-- Name: burseprivate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.burseprivate (
    id integer NOT NULL,
    idcontract integer,
    data date,
    cota real,
    suma real
);


--
-- Name: burseprivate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.burseprivate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: burseprivate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.burseprivate_id_seq OWNED BY public.burseprivate.id;


--
-- Name: caen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.caen (
    id integer NOT NULL,
    nume text
);


--
-- Name: caen_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.caen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: caen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.caen_id_seq OWNED BY public.caen.id;


--
-- Name: centrucost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.centrucost (
    id integer NOT NULL,
    idadresa integer,
    idsocietate integer,
    nume text
);


--
-- Name: centrucost_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.centrucost_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: centrucost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.centrucost_id_seq OWNED BY public.centrucost.id;


--
-- Name: cm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cm (
    dela date,
    panala date,
    continuare boolean,
    datainceput date,
    serienrcertificat text,
    dataeliberare text,
    codurgenta text,
    procent real,
    codboalainfcont text,
    bazacalcul real,
    bazacalculplafonata real,
    zilebazacalcul integer,
    mediezilnica real,
    zilefirma integer,
    indemnizatiefirma real,
    zilefnuass integer,
    indemnizatiefnuass real,
    locprescriere text,
    nravizmedic text,
    codboala text,
    urgenta boolean,
    conditii text,
    idcontract integer,
    id bigint NOT NULL
);


--
-- Name: cm_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cm_id_seq OWNED BY public.cm.id;


--
-- Name: co; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.co (
    id integer NOT NULL,
    tip text,
    dela date,
    panala date,
    sporuripermanente boolean,
    idcontract integer
);


--
-- Name: co_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.co_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: co_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.co_id_seq OWNED BY public.co.id;


--
-- Name: condica; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.condica (
    id integer NOT NULL,
    inceput timestamp with time zone,
    sfarsit timestamp with time zone,
    pauzamasa time with time zone,
    idcontract integer
);


--
-- Name: contbancar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contbancar (
    iban text NOT NULL,
    numebanca text
);


--
-- Name: contract; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract (
    id integer NOT NULL,
    tip text,
    nr text,
    marca text,
    data date,
    dataincepere date,
    idpunctlucru integer,
    idcentrucost integer,
    idechipa integer,
    iddepartament integer,
    functiedebaza boolean,
    calculdeduceri boolean,
    studiisuperioare boolean,
    normalucru text,
    salariutarifar real,
    monedasalariu text,
    modplata text,
    conditiimunca text,
    pensieprivata boolean,
    cotizatiepensieprivata real,
    avans real,
    monedaavans text,
    zilecoan integer,
    ultimazilucru date,
    casasanatate text,
    gradinvaliditate text,
    functie text,
    nivelstudii text,
    cor text,
    sindicat boolean,
    cotizatiesindicat real,
    spor text,
    pensionar boolean,
    echipa integer
);


--
-- Name: contract_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_id_seq OWNED BY public.contract.id;


--
-- Name: deduceri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deduceri (
    id integer NOT NULL,
    dela real NOT NULL,
    panala real NOT NULL,
    zero integer NOT NULL,
    una integer NOT NULL,
    doua integer NOT NULL,
    trei integer NOT NULL,
    patru integer NOT NULL
);


--
-- Name: deduceri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deduceri_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deduceri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deduceri_id_seq OWNED BY public.deduceri.id;


--
-- Name: departament; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departament (
    id integer NOT NULL,
    idadresa integer,
    idsocietate integer,
    nume text,
    adresa integer
);


--
-- Name: departament_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departament_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departament_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departament_id_seq OWNED BY public.departament.id;


--
-- Name: echipa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.echipa (
    id integer NOT NULL,
    iddepartament integer,
    nume text,
    dataschimbare timestamp without time zone NOT NULL,
    idcontract integer NOT NULL,
    idsalariat integer NOT NULL
);


--
-- Name: echipa_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.echipa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: echipa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.echipa_id_seq OWNED BY public.echipa.id;


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: listacontbancar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listacontbancar (
    idsocietate integer NOT NULL,
    iban text NOT NULL
);


--
-- Name: listasalariatcontract; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listasalariatcontract (
    idsalariat integer NOT NULL,
    idcontract integer NOT NULL,
    dataschimbare date
);


--
-- Name: oresuplimentare; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oresuplimentare (
    id integer NOT NULL,
    nr integer,
    procent real,
    includenormale boolean,
    total real,
    idcontract integer
);


--
-- Name: oresuplimentare_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oresuplimentare_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oresuplimentare_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oresuplimentare_id_seq OWNED BY public.oresuplimentare.id;


--
-- Name: parametriisalariu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parametriisalariu (
    id bigint NOT NULL,
    salariumin real NOT NULL,
    salariuminstudiivechime real NOT NULL,
    salariumediubrut real NOT NULL,
    impozit real NOT NULL,
    cas real NOT NULL,
    cass real NOT NULL,
    cam real NOT NULL,
    valtichet real NOT NULL
);


--
-- Name: parametriisalariu_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parametriisalariu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parametriisalariu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parametriisalariu_id_seq OWNED BY public.parametriisalariu.id;


--
-- Name: permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission (
    id integer NOT NULL,
    name text
);


--
-- Name: permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permission_id_seq OWNED BY public.permission.id;


--
-- Name: persoana; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.persoana (
    id integer NOT NULL,
    gen text,
    nume text,
    prenume text,
    idactidentitate integer,
    idadresa integer,
    starecivila text,
    email text,
    telefon text,
    cnp text
);


--
-- Name: persoana_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.persoana_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: persoana_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.persoana_id_seq OWNED BY public.persoana.id;


--
-- Name: persoanaintretinere; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.persoanaintretinere (
    id integer NOT NULL,
    nume text,
    prenume text,
    cnp text,
    datanasterii date,
    grad text,
    gradinvaliditate text,
    intretinut boolean,
    coasigurat boolean,
    idaangajat bigint
);


--
-- Name: persoanaintretinere_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.persoanaintretinere_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: persoanaintretinere_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.persoanaintretinere_id_seq OWNED BY public.persoanaintretinere.id;


--
-- Name: prime; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prime (
    id integer NOT NULL,
    valoare real,
    idstat integer,
    idcontract bigint,
    data date
);


--
-- Name: prime_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prime_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prime_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prime_id_seq OWNED BY public.prime.id;


--
-- Name: punctdelucru; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.punctdelucru (
    id integer NOT NULL,
    idadresa integer,
    idsocietate integer,
    nume text
);


--
-- Name: punctlucru_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.punctlucru_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: punctlucru_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.punctlucru_id_seq OWNED BY public.punctdelucru.id;


--
-- Name: retineri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retineri (
    id integer NOT NULL,
    valoare real,
    idstat integer
);


--
-- Name: role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role (
    id integer NOT NULL,
    name text,
    "desc" text
);


--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: roletopermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roletopermission (
    roleid integer NOT NULL,
    permissionid integer NOT NULL
);


--
-- Name: salariat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salariat (
    id integer NOT NULL,
    idpersoana integer
);


--
-- Name: salariat_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salariat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salariat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salariat_id_seq OWNED BY public.salariat.id;


--
-- Name: sarbatori; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sarbatori (
    id integer NOT NULL,
    dela date,
    panala date,
    nume text
);


--
-- Name: sarbatori_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sarbatori_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sarbatori_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sarbatori_id_seq OWNED BY public.sarbatori.id;


--
-- Name: societate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.societate (
    id integer NOT NULL,
    nume text NOT NULL,
    idcaen integer,
    cif text,
    capsoc real,
    regcom text,
    idadresa integer,
    email text,
    telefon text,
    idcontract bigint,
    includenormale boolean,
    nr bigint,
    procent double precision,
    total double precision
);


--
-- Name: societate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.societate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: societate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.societate_id_seq OWNED BY public.societate.id;


--
-- Name: sponsorizari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sponsorizari (
    id integer NOT NULL,
    idcontract integer,
    denumire text,
    cui text,
    cota real,
    suma real
);


--
-- Name: sponsorizari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sponsorizari_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sponsorizari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sponsorizari_id_seq OWNED BY public.sponsorizari.id;


--
-- Name: spor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spor (
    id integer NOT NULL,
    nume text,
    valoare real,
    procent real,
    aplicare text,
    idstat integer
);


--
-- Name: spor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spor_id_seq OWNED BY public.spor.id;


--
-- Name: sporpermanent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sporpermanent (
    id integer NOT NULL,
    nume text,
    valoare real,
    procent real,
    aplicare text,
    idcontract integer,
    idstat bigint
);


--
-- Name: sporpermanent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sporpermanent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sporpermanent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sporpermanent_id_seq OWNED BY public.sporpermanent.id;


--
-- Name: statsalariat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statsalariat (
    id integer NOT NULL,
    data date,
    idcontract integer
);


--
-- Name: statsalariat_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statsalariat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statsalariat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statsalariat_id_seq OWNED BY public.statsalariat.id;


--
-- Name: tichete; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tichete (
    id integer NOT NULL,
    tip text,
    nr integer,
    restituite integer,
    valoare real,
    impozabil boolean,
    idstat integer,
    idcontract bigint
);


--
-- Name: tichete_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tichete_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tichete_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tichete_id_seq OWNED BY public.tichete.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username text,
    password text,
    nume text,
    prenume text,
    societateselectata integer
);


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: usertorole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usertorole (
    userid integer NOT NULL,
    roleid integer NOT NULL
);


--
-- Name: zilecodisponibile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zilecodisponibile (
    id integer NOT NULL,
    nr integer,
    idcontract integer
);


--
-- Name: zilecodisponibile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.zilecodisponibile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zilecodisponibile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.zilecodisponibile_id_seq OWNED BY public.zilecodisponibile.id;


--
-- Name: actidentitate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actidentitate ALTER COLUMN id SET DEFAULT nextval('public.actidentitate_id_seq'::regclass);


--
-- Name: adresa id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adresa ALTER COLUMN id SET DEFAULT nextval('public.adresa_id_seq'::regclass);


--
-- Name: altebeneficii id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.altebeneficii ALTER COLUMN id SET DEFAULT nextval('public.altebeneficii_id_seq'::regclass);


--
-- Name: altedrepturi id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.altedrepturi ALTER COLUMN id SET DEFAULT nextval('public.altedrepturi_id_seq'::regclass);


--
-- Name: burseprivate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.burseprivate ALTER COLUMN id SET DEFAULT nextval('public.burseprivate_id_seq'::regclass);


--
-- Name: caen id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.caen ALTER COLUMN id SET DEFAULT nextval('public.caen_id_seq'::regclass);


--
-- Name: centrucost id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.centrucost ALTER COLUMN id SET DEFAULT nextval('public.centrucost_id_seq'::regclass);


--
-- Name: cm id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cm ALTER COLUMN id SET DEFAULT nextval('public.cm_id_seq'::regclass);


--
-- Name: co id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.co ALTER COLUMN id SET DEFAULT nextval('public.co_id_seq'::regclass);


--
-- Name: contract id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract ALTER COLUMN id SET DEFAULT nextval('public.contract_id_seq'::regclass);


--
-- Name: deduceri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deduceri ALTER COLUMN id SET DEFAULT nextval('public.deduceri_id_seq'::regclass);


--
-- Name: departament id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departament ALTER COLUMN id SET DEFAULT nextval('public.departament_id_seq'::regclass);


--
-- Name: echipa id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.echipa ALTER COLUMN id SET DEFAULT nextval('public.echipa_id_seq'::regclass);


--
-- Name: oresuplimentare id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oresuplimentare ALTER COLUMN id SET DEFAULT nextval('public.oresuplimentare_id_seq'::regclass);


--
-- Name: parametriisalariu id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametriisalariu ALTER COLUMN id SET DEFAULT nextval('public.parametriisalariu_id_seq'::regclass);


--
-- Name: permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission ALTER COLUMN id SET DEFAULT nextval('public.permission_id_seq'::regclass);


--
-- Name: persoana id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persoana ALTER COLUMN id SET DEFAULT nextval('public.persoana_id_seq'::regclass);


--
-- Name: persoanaintretinere id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persoanaintretinere ALTER COLUMN id SET DEFAULT nextval('public.persoanaintretinere_id_seq'::regclass);


--
-- Name: prime id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prime ALTER COLUMN id SET DEFAULT nextval('public.prime_id_seq'::regclass);


--
-- Name: punctdelucru id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.punctdelucru ALTER COLUMN id SET DEFAULT nextval('public.punctlucru_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: salariat id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salariat ALTER COLUMN id SET DEFAULT nextval('public.salariat_id_seq'::regclass);


--
-- Name: sarbatori id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sarbatori ALTER COLUMN id SET DEFAULT nextval('public.sarbatori_id_seq'::regclass);


--
-- Name: societate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.societate ALTER COLUMN id SET DEFAULT nextval('public.societate_id_seq'::regclass);


--
-- Name: sponsorizari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorizari ALTER COLUMN id SET DEFAULT nextval('public.sponsorizari_id_seq'::regclass);


--
-- Name: spor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spor ALTER COLUMN id SET DEFAULT nextval('public.spor_id_seq'::regclass);


--
-- Name: sporpermanent id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sporpermanent ALTER COLUMN id SET DEFAULT nextval('public.sporpermanent_id_seq'::regclass);


--
-- Name: statsalariat id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statsalariat ALTER COLUMN id SET DEFAULT nextval('public.statsalariat_id_seq'::regclass);


--
-- Name: tichete id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tichete ALTER COLUMN id SET DEFAULT nextval('public.tichete_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: zilecodisponibile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zilecodisponibile ALTER COLUMN id SET DEFAULT nextval('public.zilecodisponibile_id_seq'::regclass);


--
-- Name: actidentitate actidentitate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actidentitate
    ADD CONSTRAINT actidentitate_pkey PRIMARY KEY (id);


--
-- Name: adresa adresa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adresa
    ADD CONSTRAINT adresa_pkey PRIMARY KEY (id);


--
-- Name: altebeneficii altebeneficii_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.altebeneficii
    ADD CONSTRAINT altebeneficii_pkey PRIMARY KEY (id);


--
-- Name: altedrepturi altedrepturi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.altedrepturi
    ADD CONSTRAINT altedrepturi_pkey PRIMARY KEY (id);


--
-- Name: angajat angajat_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.angajat
    ADD CONSTRAINT angajat_key PRIMARY KEY (idpersoana);


--
-- Name: burseprivate burseprivate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.burseprivate
    ADD CONSTRAINT burseprivate_pkey PRIMARY KEY (id);


--
-- Name: caen caen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.caen
    ADD CONSTRAINT caen_pkey PRIMARY KEY (id);


--
-- Name: centrucost centrucost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.centrucost
    ADD CONSTRAINT centrucost_pkey PRIMARY KEY (id);


--
-- Name: cm cm_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cm
    ADD CONSTRAINT cm_pkey PRIMARY KEY (id);


--
-- Name: co co_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.co
    ADD CONSTRAINT co_pkey PRIMARY KEY (id);


--
-- Name: condica condica_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.condica
    ADD CONSTRAINT condica_pkey PRIMARY KEY (id);


--
-- Name: contbancar contbancar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contbancar
    ADD CONSTRAINT contbancar_pkey PRIMARY KEY (iban);


--
-- Name: contract contract_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_pkey PRIMARY KEY (id);


--
-- Name: deduceri deduceri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deduceri
    ADD CONSTRAINT deduceri_pkey PRIMARY KEY (id);


--
-- Name: departament departament_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departament
    ADD CONSTRAINT departament_pkey PRIMARY KEY (id);


--
-- Name: echipa echipa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.echipa
    ADD CONSTRAINT echipa_pkey PRIMARY KEY (id);


--
-- Name: user id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT id PRIMARY KEY (id);


--
-- Name: listacontbancar listacontbancar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listacontbancar
    ADD CONSTRAINT listacontbancar_pkey PRIMARY KEY (idsocietate, iban);


--
-- Name: listasalariatcontract listasalariatcontract_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listasalariatcontract
    ADD CONSTRAINT listasalariatcontract_pkey PRIMARY KEY (idsalariat, idcontract);


--
-- Name: permission name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT name_unique UNIQUE (name);


--
-- Name: oresuplimentare oresuplimentare_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oresuplimentare
    ADD CONSTRAINT oresuplimentare_pkey PRIMARY KEY (id);


--
-- Name: parametriisalariu parametriisalariu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametriisalariu
    ADD CONSTRAINT parametriisalariu_pkey PRIMARY KEY (id);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (id);


--
-- Name: persoana persoana_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persoana
    ADD CONSTRAINT persoana_pkey PRIMARY KEY (id);


--
-- Name: persoanaintretinere persoanaintretinere_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persoanaintretinere
    ADD CONSTRAINT persoanaintretinere_pkey PRIMARY KEY (id);


--
-- Name: prime prime_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prime
    ADD CONSTRAINT prime_pkey PRIMARY KEY (id);


--
-- Name: punctdelucru punctlucru_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.punctdelucru
    ADD CONSTRAINT punctlucru_pkey PRIMARY KEY (id);


--
-- Name: retineri retineri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retineri
    ADD CONSTRAINT retineri_pkey PRIMARY KEY (id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: role rolename_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT rolename_unique UNIQUE (name);


--
-- Name: roletopermission roletopermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roletopermission
    ADD CONSTRAINT roletopermission_pkey PRIMARY KEY (roleid, permissionid);


--
-- Name: salariat salariat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salariat
    ADD CONSTRAINT salariat_pkey PRIMARY KEY (id);


--
-- Name: sarbatori sarbatori_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sarbatori
    ADD CONSTRAINT sarbatori_pkey PRIMARY KEY (id);


--
-- Name: societate societate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.societate
    ADD CONSTRAINT societate_pkey PRIMARY KEY (id);


--
-- Name: sponsorizari sponsorizari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorizari
    ADD CONSTRAINT sponsorizari_pkey PRIMARY KEY (id);


--
-- Name: spor spor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spor
    ADD CONSTRAINT spor_pkey PRIMARY KEY (id);


--
-- Name: sporpermanent sporpermanent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sporpermanent
    ADD CONSTRAINT sporpermanent_pkey PRIMARY KEY (id);


--
-- Name: statsalariat statsalariat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statsalariat
    ADD CONSTRAINT statsalariat_pkey PRIMARY KEY (id);


--
-- Name: tichete tichete_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tichete
    ADD CONSTRAINT tichete_pkey PRIMARY KEY (id);


--
-- Name: user username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT username_unique UNIQUE (username);


--
-- Name: usertorole usertorole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usertorole
    ADD CONSTRAINT usertorole_pkey PRIMARY KEY (userid, roleid);


--
-- Name: zilecodisponibile zilecodisponibile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zilecodisponibile
    ADD CONSTRAINT zilecodisponibile_pkey PRIMARY KEY (id);


--
-- Name: listasalariatcontract 	idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listasalariatcontract
    ADD CONSTRAINT "	idcontract_fk" FOREIGN KEY (idcontract) REFERENCES public.contract(id) ON DELETE SET NULL NOT VALID;


--
-- Name: listacontbancar iban_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listacontbancar
    ADD CONSTRAINT iban_fk FOREIGN KEY (iban) REFERENCES public.contbancar(iban) NOT VALID;


--
-- Name: persoana idactidentitate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persoana
    ADD CONSTRAINT idactidentitate_fk FOREIGN KEY (idactidentitate) REFERENCES public.actidentitate(id) ON DELETE SET NULL NOT VALID;


--
-- Name: persoana idadresa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persoana
    ADD CONSTRAINT idadresa_fk FOREIGN KEY (idadresa) REFERENCES public.adresa(id) ON DELETE SET NULL NOT VALID;


--
-- Name: societate idadresa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.societate
    ADD CONSTRAINT idadresa_fk FOREIGN KEY (idadresa) REFERENCES public.adresa(id) ON DELETE SET NULL NOT VALID;


--
-- Name: centrucost idadresa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.centrucost
    ADD CONSTRAINT idadresa_fk FOREIGN KEY (idadresa) REFERENCES public.adresa(id) ON DELETE SET NULL NOT VALID;


--
-- Name: departament idadresa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departament
    ADD CONSTRAINT idadresa_fk FOREIGN KEY (idadresa) REFERENCES public.adresa(id) ON DELETE SET NULL NOT VALID;


--
-- Name: punctdelucru idadresa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.punctdelucru
    ADD CONSTRAINT idadresa_fk FOREIGN KEY (idadresa) REFERENCES public.adresa(id) ON DELETE SET NULL NOT VALID;


--
-- Name: societate idcaen_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.societate
    ADD CONSTRAINT idcaen_fk FOREIGN KEY (idcaen) REFERENCES public.caen(id) ON DELETE SET NULL NOT VALID;


--
-- Name: contract idcentrucost_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT idcentrucost_fk FOREIGN KEY (idcentrucost) REFERENCES public.centrucost(id) ON DELETE SET NULL NOT VALID;


--
-- Name: sporpermanent idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sporpermanent
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: altebeneficii idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.altebeneficii
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: burseprivate idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.burseprivate
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: sponsorizari idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorizari
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: zilecodisponibile idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zilecodisponibile
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: co idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.co
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: condica idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.condica
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: statsalariat idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statsalariat
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id);


--
-- Name: angajat idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.angajat
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id) ON DELETE SET NULL NOT VALID;


--
-- Name: oresuplimentare idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oresuplimentare
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id) ON DELETE SET NULL NOT VALID;


--
-- Name: cm idcontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cm
    ADD CONSTRAINT idcontract_fk FOREIGN KEY (idcontract) REFERENCES public.contract(id) ON DELETE SET NULL NOT VALID;


--
-- Name: echipa iddepartament_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.echipa
    ADD CONSTRAINT iddepartament_fk FOREIGN KEY (iddepartament) REFERENCES public.departament(id) ON DELETE SET NULL NOT VALID;


--
-- Name: contract iddepartament_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT iddepartament_fk FOREIGN KEY (iddepartament) REFERENCES public.departament(id) ON DELETE SET NULL NOT VALID;


--
-- Name: contract idechipa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT idechipa_fk FOREIGN KEY (idechipa) REFERENCES public.echipa(id) ON DELETE SET NULL NOT VALID;


--
-- Name: salariat idpersoana_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salariat
    ADD CONSTRAINT idpersoana_fk FOREIGN KEY (idpersoana) REFERENCES public.persoana(id);


--
-- Name: angajat idpersoana_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.angajat
    ADD CONSTRAINT idpersoana_fk FOREIGN KEY (idpersoana) REFERENCES public.persoana(id) ON DELETE SET NULL;


--
-- Name: contract idpunctlucru_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT idpunctlucru_fk FOREIGN KEY (idpunctlucru) REFERENCES public.punctdelucru(id) ON DELETE SET NULL NOT VALID;


--
-- Name: listasalariatcontract idsalariat_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listasalariatcontract
    ADD CONSTRAINT idsalariat_fk FOREIGN KEY (idsalariat) REFERENCES public.contract(id) ON DELETE SET NULL NOT VALID;


--
-- Name: listacontbancar idsocietate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listacontbancar
    ADD CONSTRAINT idsocietate_fk FOREIGN KEY (idsocietate) REFERENCES public.societate(id) NOT VALID;


--
-- Name: centrucost idsocietate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.centrucost
    ADD CONSTRAINT idsocietate_fk FOREIGN KEY (idsocietate) REFERENCES public.societate(id) ON DELETE SET NULL NOT VALID;


--
-- Name: departament idsocietate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departament
    ADD CONSTRAINT idsocietate_fk FOREIGN KEY (idsocietate) REFERENCES public.societate(id) ON DELETE SET NULL NOT VALID;


--
-- Name: angajat idsocietate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.angajat
    ADD CONSTRAINT idsocietate_fk FOREIGN KEY (idsocietate) REFERENCES public.societate(id) ON DELETE SET NULL NOT VALID;


--
-- Name: punctdelucru idsocietate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.punctdelucru
    ADD CONSTRAINT idsocietate_fk FOREIGN KEY (idsocietate) REFERENCES public.societate(id) ON DELETE SET NULL NOT VALID;


--
-- Name: altedrepturi idstat_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.altedrepturi
    ADD CONSTRAINT idstat_fk FOREIGN KEY (idstat) REFERENCES public.statsalariat(id);


--
-- Name: retineri idstat_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retineri
    ADD CONSTRAINT idstat_fk FOREIGN KEY (idstat) REFERENCES public.statsalariat(id) ON DELETE SET NULL NOT VALID;


--
-- Name: prime idstat_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prime
    ADD CONSTRAINT idstat_fk FOREIGN KEY (idstat) REFERENCES public.statsalariat(id) ON DELETE SET NULL NOT VALID;


--
-- Name: spor idstat_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spor
    ADD CONSTRAINT idstat_fk FOREIGN KEY (idstat) REFERENCES public.statsalariat(id) ON DELETE SET NULL NOT VALID;


--
-- Name: tichete idstat_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tichete
    ADD CONSTRAINT idstat_fk FOREIGN KEY (idstat) REFERENCES public.statsalariat(id) ON DELETE SET NULL NOT VALID;


--
-- Name: roletopermission permissionid_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roletopermission
    ADD CONSTRAINT permissionid_fk FOREIGN KEY (permissionid) REFERENCES public.permission(id) ON DELETE SET NULL NOT VALID;


--
-- Name: roletopermission roleid_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roletopermission
    ADD CONSTRAINT roleid_fk FOREIGN KEY (roleid) REFERENCES public.role(id) ON DELETE SET NULL NOT VALID;


--
-- Name: usertorole roleid_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usertorole
    ADD CONSTRAINT roleid_fk FOREIGN KEY (roleid) REFERENCES public.role(id) ON DELETE CASCADE NOT VALID;


--
-- Name: user societateselectata_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT societateselectata_fk FOREIGN KEY (societateselectata) REFERENCES public.societate(id) ON DELETE SET NULL;


--
-- Name: usertorole userid_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usertorole
    ADD CONSTRAINT userid_fk FOREIGN KEY (userid) REFERENCES public."user"(id) ON DELETE CASCADE NOT VALID;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO webadmin;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

